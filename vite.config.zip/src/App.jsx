import {useLayoutEffect,useRef} from 'react'
import gsap from 'gsap'
import {ScrollTrigger} from 'gsap/ScrollTrigger'
import Lenis from 'lenis'
import Scene from './Scene.jsx'
gsap.registerPlugin(ScrollTrigger)

const PHONE='+91 9660633043',WA='https://wa.me/919660633043',MAIL='dishikadoshi2930@gmail.com',LI='https://www.linkedin.com/in/dishikadoshi/'
const manifesto="I design and build web products that feel effortless to use and are engineered to last. Clean architecture, considered interfaces and performance that holds up under real traffic."
const services=[['Full stack development','React, Next.js, Node.js and Go, built on clean architecture with test coverage.'],
 ['Interface engineering','Accessible components, precise motion and design systems that scale across teams.'],
 ['APIs and backend systems','REST and GraphQL services, database design, authentication and integrations.'],
 ['Cloud and DevOps','CI/CD, containers and Kubernetes on AWS or GCP, automated and monitored.'],
 ['Performance','Core Web Vitals, bundle analysis and query tuning for existing products.']]
const projects=[['NovaPay','Fintech dashboard','Real-time analytics with live WebSocket updates and fast queries.','React · Node.js · PostgreSQL','M0 90 C60 85 90 40 150 55 S250 20 320 10'],
 ['Orbis','SaaS platform','A multi-tenant platform built for reliability and quick response times.','Next.js · Go · Redis','M0 70 C50 20 100 90 160 50 S260 80 320 30'],
 ['Pulse','Health app','Cross-platform health tracking with Apple Health integration.','React Native · TypeScript','M0 80 L60 60 L110 75 L170 30 L230 45 L320 15'],
 ['Luxe','E-commerce platform','A fast storefront with a large page-speed gain and Stripe checkout.','Next.js · Tailwind · Stripe','M0 95 C80 90 120 60 180 40 S280 30 320 5']]
const steps=[['Discovery','Goals, users and constraints first. Success metrics are agreed before any code is written.'],
 ['Design and architecture','Wireframes and system design, with each decision documented.'],
 ['Build and iterate','Short sprints with weekly demos so feedback lands early.'],
 ['Launch and support','Zero-downtime deploys, monitoring and 30 days of support after launch.']]
const skills=['React','Next.js','TypeScript','Node.js','Go','PostgreSQL','Redis','GraphQL','Docker','Kubernetes','AWS','GCP','Figma','Three.js']

export default function App(){
  const prog=useRef(0),root=useRef()
  useLayoutEffect(()=>{
    const lenis=new Lenis({lerp:.09});lenis.on('scroll',ScrollTrigger.update)
    const tick=t=>lenis.raf(t*1000);gsap.ticker.add(tick);gsap.ticker.lagSmoothing(0)
    const ctx=gsap.context(()=>{
      gsap.from('.hl i',{yPercent:115,duration:1.6,stagger:.14,ease:'expo.out',delay:.15})
      gsap.from('.fade-in',{opacity:0,y:20,duration:1.2,delay:.9,stagger:.12,ease:'power3.out'})
      gsap.timeline({scrollTrigger:{trigger:'.hero',start:'top top',end:'+=110%',pin:true,scrub:true,onUpdate:s=>prog.current=s.progress}})
        .to('.hl i',{yPercent:-120,stagger:.08,ease:'power2.in'},0).to('.hero-side',{opacity:0,y:-40},0)
      gsap.fromTo('.w',{opacity:.14},{opacity:1,stagger:.12,ease:'none',scrollTrigger:{trigger:'.manifesto',start:'top 75%',end:'bottom 70%',scrub:true}})
      gsap.utils.toArray('.row').forEach(r=>{
        gsap.from(r.querySelector('.ln'),{scaleX:0,transformOrigin:'left',ease:'none',scrollTrigger:{trigger:r,start:'top 90%',end:'top 65%',scrub:true}})
        gsap.from(r.querySelectorAll('h3,p'),{y:50,opacity:0,stagger:.08,ease:'none',scrollTrigger:{trigger:r,start:'top 90%',end:'top 60%',scrub:true}})})
      const track=document.querySelector('.track')
      const h=gsap.to(track,{x:()=>-(track.scrollWidth-innerWidth),ease:'none',scrollTrigger:{trigger:'.work',start:'top top',end:()=>'+='+(track.scrollWidth-innerWidth),pin:true,scrub:.6,invalidateOnRefresh:true}})
      gsap.utils.toArray('.panel .shot').forEach(s=>gsap.fromTo(s,{xPercent:-10,scale:.94},{xPercent:10,scale:1,ease:'none',scrollTrigger:{trigger:s.closest('.panel'),containerAnimation:h,start:'left right',end:'right left',scrub:true}}))
      gsap.utils.toArray('.panel path').forEach(p=>{const L=p.getTotalLength();gsap.fromTo(p,{strokeDasharray:L,strokeDashoffset:L},{strokeDashoffset:0,ease:'none',scrollTrigger:{trigger:p.closest('.panel'),containerAnimation:h,start:'left 80%',end:'left 20%',scrub:true}})})
      gsap.to('.rail-fill',{scaleY:1,ease:'none',scrollTrigger:{trigger:'.steps',start:'top 60%',end:'bottom 60%',scrub:true}})
      gsap.utils.toArray('.step').forEach(s=>ScrollTrigger.create({trigger:s,start:'top 60%',end:'bottom 60%',toggleClass:{targets:s,className:'on'}}))
      gsap.from('.cl i',{yPercent:115,stagger:.12,duration:1.3,ease:'expo.out',scrollTrigger:{trigger:'.contact',start:'top 65%'}})
      gsap.from('.contact-list a',{opacity:0,y:30,stagger:.1,scrollTrigger:{trigger:'.contact-list',start:'top 85%'}})
    },root)
    return()=>{ctx.revert();gsap.ticker.remove(tick);lenis.destroy()}
  },[])
  return <div ref={root}>
    <nav><a href="#top" className="logo">Dishika Doshi</a><ul>{['About','Services','Work','Process','Contact'].map(s=><li key={s}><a href={'#'+s.toLowerCase()}>{s}</a></li>)}</ul></nav>

    <header className="hero" id="top"><Scene prog={prog}/><div className="shade"/>
      <h1 className="hl"><span><i>Dishika</i></span><span><i>Doshi</i></span></h1>
      <div className="hero-side fade-in"><p>Full stack developer building precise, fast and considered web products.</p><a className="btn" href="#contact">Start a project</a></div>
    </header>

    <section id="about" className="manifesto wrap"><p className="big">{manifesto.split(' ').map((w,i)=><span key={i} className="w">{w} </span>)}</p>
      <ul className="skills">{skills.map(s=><li key={s}>{s}</li>)}</ul></section>

    <section id="services" className="wrap"><h2>Services</h2>
      {services.map(([t,d])=><div className="row" key={t}><span className="ln"/><h3>{t}</h3><p>{d}</p></div>)}<span className="ln end"/></section>

    <section id="work" className="work"><div className="track">
      <div className="intro panel"><h2>Selected work</h2><p>Four products, each built from interface to infrastructure.</p></div>
      {projects.map(([n,k,d,tags,path])=><article className="panel" key={n}>
        <div className="shot"><svg viewBox="0 0 320 100" preserveAspectRatio="none"><path d={path} fill="none" stroke="#8fa8ff" strokeWidth="1.5" vectorEffect="non-scaling-stroke"/></svg><span>{n}</span></div>
        <div className="meta"><h3>{n}<em> {k}</em></h3><p>{d}</p><small>{tags}</small></div></article>)}
    </div></section>

    <section id="process" className="wrap proc"><div className="sticky"><h2>How I work</h2></div>
      <div className="steps"><div className="rail"><div className="rail-fill"/></div>
        {steps.map(([t,d],i)=><div className="step" key={t}><span>{i+1}</span><h3>{t}</h3><p>{d}</p></div>)}</div></section>

    <section id="contact" className="contact wrap">
      <h2 className="cl"><span><i>Let’s build</i></span><span><i>something precise.</i></span></h2>
      <div className="contact-list">
        <a href={'mailto:'+MAIL}><small>Email</small>{MAIL}</a>
        <a href="tel:+919660633043"><small>Phone</small>{PHONE}</a>
        <a href={WA} target="_blank" rel="noreferrer"><small>WhatsApp</small>{PHONE}</a>
        <a href={LI} target="_blank" rel="noreferrer"><small>LinkedIn</small>/in/dishikadoshi</a></div></section>
    <footer><span>© 2026 Dishika Doshi</span><a href="#top">Back to top</a></footer>
  </div>
}
